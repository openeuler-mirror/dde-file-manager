<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Application</name>
    <message>
        <location filename="../main.cpp" line="117"/>
        <source>File Manager</source>
        <translation>文件管理器</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="121"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>文件管理器是一款功能强大的文件管理工具， 它包括搜索、复制、回收站、压缩/解压缩， 文件属性等管理功能。</translation>
    </message>
</context>
</TS>
