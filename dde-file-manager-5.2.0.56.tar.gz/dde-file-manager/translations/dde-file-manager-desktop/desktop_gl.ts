<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="gl">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Browse the file system</source>
            <translation>Examinar o sistema de ficheiros</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Deepin File Manager</source>
            <translation>Xestor de ficheiros</translation>
        </message>
        <message>
            <location filename="Desktop Action new-window]Name" line="0"/>
            <source>New Window</source>
            <translation>Nova xanela</translation>
        </message>
    </context>
</TS>
