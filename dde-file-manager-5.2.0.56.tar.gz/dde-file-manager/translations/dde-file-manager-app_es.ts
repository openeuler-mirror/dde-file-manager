<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Gestor de archivos Deepin</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>Gestor de archivos</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>El Gestor de archivos es una herramienta de gestión de archivos potente y fácil de usar, con funciones de búsqueda, copia, papelera, compresión/descompresión, propiedad de archivos y otras funciones útiles.</translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">El Gestor de archivos Deepin es una herramienta, desarrollada de manera independiente por Deepin Technology, con características como búsqueda, copiado, papelera de reciclaje, compresión/descompresión, propiedades de archivo y otras funciones referidas al manejo de estos.</translation>
    </message>
</context>
</TS>