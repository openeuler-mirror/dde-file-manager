<?xml version="1.0" ?><!DOCTYPE TS><TS language="it" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Deepin File Manager</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>File Manager</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>File Manager è uno strumento di gestione file con funzionalità di ricerca, copia, compressione/decompressione, dettagli dei file ed altre funzionalità.
Localizzazione italiana a cura di Massimo A. Carofano. </translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">File manager è uno strumento di gestione files indipendente sviluppato da Deepin Technology, munito di funzionalità di ricerca, copia, cestinazione, compressione/decompressione, dettaglio delle proprietà dei files ed altre funzionalità di gestione.
Localizzazione italiana a cura di Massimo A. Carofano.</translation>
    </message>
</context>
</TS>