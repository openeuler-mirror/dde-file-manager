<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>CanvasGridView</name>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2482"/>
        <source>Icon size</source>
        <translation>Tamanho do ícone</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2488"/>
        <source>Auto merge</source>
        <translation>Agrupar automaticamente</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2503"/>
        <source>Auto arrange</source>
        <translation>Organizar automaticamente</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2559"/>
        <source>Set Wallpaper</source>
        <translation>Definir Papel de parede</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2561"/>
        <source>Wallpaper and Screensaver</source>
        <translation>Papel de parede e Protector de ecrã</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2642"/>
        <source>Properties</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2543"/>
        <source>Display Settings</source>
        <translation>Definições de visualização</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2552"/>
        <source>Corner Settings</source>
        <translation>Definições de cantos</translation>
    </message>
</context>
<context>
    <name>DesktopItemDelegate</name>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="40"/>
        <source>Tiny</source>
        <translation>Minúsculo</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="41"/>
        <source>Small</source>
        <translation>Pequeno</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="42"/>
        <source>Medium</source>
        <translation>Médio</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="43"/>
        <source>Large</source>
        <translation>Grande</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="44"/>
        <source>Super large</source>
        <translation>Enorme</translation>
    </message>
</context>
<context>
    <name>DesktopMain</name>
    <message>
        <location filename="../main.cpp" line="131"/>
        <source>Desktop</source>
        <translation>Ambiente de trabalho</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="450"/>
        <source>Wallpaper Slideshow</source>
        <translation>Apresentação de diapositivos de papel de parede</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="482"/>
        <source>When login</source>
        <translation>Quando iniciar sessão</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="484"/>
        <source>When wakeup</source>
        <translation>Quando retomar sessão</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="528"/>
        <source>Require a password on wakeup</source>
        <translation>Requer palavra-passe ao retomar sessão</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="558"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="559"/>
        <source>Wait:</source>
        <translation>Aguarde:</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="592"/>
        <source>Wallpaper</source>
        <translation>Papel de parede</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="593"/>
        <source>Screensaver</source>
        <translation>Protector de ecrã</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="666"/>
        <source>Only desktop</source>
        <translation>Apenas ambiente de trabalho</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="667"/>
        <source>Only lock screen</source>
        <translation>Apenas ecrã de bloqueio</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="695"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
</context>
<context>
    <name>ZoneMainWindow</name>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Fast Screen Off</source>
        <translation>Desligar ecrã rápido</translation>
    </message>
    <message>
        <source>Control Center</source>
        <translation type="vanished">Centro de Controlo</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>All Windows</source>
        <translation>Todas as Janelas</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Launcher</source>
        <translation>Lançador</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Desktop</source>
        <translation>Ambiente de trabalho</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="58"/>
        <source>Close Window</source>
        <translation>Fechar Janela</translation>
    </message>
</context>
</TS>