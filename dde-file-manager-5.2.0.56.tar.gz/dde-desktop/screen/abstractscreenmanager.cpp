#include "abstractscreenmanager.h"

AbstractScreenManager::AbstractScreenManager(QObject *parent)
    : QObject(parent)
{

}

AbstractScreenManager::~AbstractScreenManager()
{

}
