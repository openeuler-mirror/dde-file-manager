<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Gestor de Ficheiros Deepin</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>Gestor de Ficheiros</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>O Gestor de Ficheiros é uma ferramenta de gestão de ficheiros poderosa e fácil de usar, que inclui pesquisar, copiar, eliminar, comprimir/extrair, consultar propriedades dos ficheiros e outras funções úteis.</translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">O Gestor de Ficheiros é uma ferramenta de gestão de ficheiros desenvolvida independentemente pela &quot;Deepin Technology&quot;, com funcionalidades de pesquisar, copiar, eliminar, comprimir/extrair, consultar as propriedades dos ficheiros e outras funções de gestão de ficheiros.</translation>
    </message>
</context>
</TS>