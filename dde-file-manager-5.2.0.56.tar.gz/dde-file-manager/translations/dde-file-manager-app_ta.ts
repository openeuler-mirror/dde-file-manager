<?xml version="1.0" ?><!DOCTYPE TS><TS language="ta" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">டீபைன் கோப்பு மேலாளர்</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">கோப்பு மேலாளர் என்பது டீபைன் டெக்னாலஜி சுயாதீனமாக உருவாக்கிய ஒரு கோப்பு நிர்வாக கருவி ஆகும், இது தேடல், நகல், குப்பை, சுருக்க / டிகம்பரஷன், கோப்பு விவரங்கள் மற்றும் பிற கோப்பு மேலாண்மை செயல்பாடுகளை கொண்டுள்ளது.</translation>
    </message>
</context>
</TS>