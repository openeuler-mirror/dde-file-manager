<?xml version="1.0" ?><!DOCTYPE TS><TS language="el" version="2.1">
<context>
    <name>CanvasGridView</name>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2482"/>
        <source>Icon size</source>
        <translation>Μέγεθος εικονιδίων</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2488"/>
        <source>Auto merge</source>
        <translation>Αυτόματη συγχώνευση</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2503"/>
        <source>Auto arrange</source>
        <translation>Αυτόματη στοίχιση</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2559"/>
        <source>Set Wallpaper</source>
        <translation>Ορισμός Ταπετσαρίας</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2561"/>
        <source>Wallpaper and Screensaver</source>
        <translation>Wallpaper και Screensaver</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2642"/>
        <source>Properties</source>
        <translation>Ιδιότητες</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2543"/>
        <source>Display Settings</source>
        <translation>Ρυθμίσεις Εμφάνισης</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2552"/>
        <source>Corner Settings</source>
        <translation>Ρυθμίσεις Γωνίας</translation>
    </message>
</context>
<context>
    <name>DesktopItemDelegate</name>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="40"/>
        <source>Tiny</source>
        <translation>Μικρούλικο</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="41"/>
        <source>Small</source>
        <translation>Μικρό</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="42"/>
        <source>Medium</source>
        <translation>Μεσσαίο</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="43"/>
        <source>Large</source>
        <translation>Μεγάλο</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="44"/>
        <source>Super large</source>
        <translation>Τεράστιο</translation>
    </message>
</context>
<context>
    <name>DesktopMain</name>
    <message>
        <location filename="../main.cpp" line="131"/>
        <source>Desktop</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="450"/>
        <source>Wallpaper Slideshow</source>
        <translation>Wallpaper Slideshow</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="482"/>
        <source>When login</source>
        <translation>Στη σύνδεση</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="484"/>
        <source>When wakeup</source>
        <translation>Στην αφύπνιση </translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="528"/>
        <source>Require a password on wakeup</source>
        <translation>Απαίτηση κωδικού πρόσβασης κατά την αφύπνιση</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="558"/>
        <source>Never</source>
        <translation>Ποτέ</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="559"/>
        <source>Wait:</source>
        <translation>Αναμονή:</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="592"/>
        <source>Wallpaper</source>
        <translation>Wallpaper</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="593"/>
        <source>Screensaver</source>
        <translation>Screensaver</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="666"/>
        <source>Only desktop</source>
        <translation>Μόνο η επιφάνεια εργασίας</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="667"/>
        <source>Only lock screen</source>
        <translation>Μόνο το κλείδωμα οθόνης</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="695"/>
        <source>Apply</source>
        <translation>Εφαρμογή</translation>
    </message>
</context>
<context>
    <name>ZoneMainWindow</name>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Fast Screen Off</source>
        <translation>Γρήγορο Κλείσιμο Οθόνης</translation>
    </message>
    <message>
        <source>Control Center</source>
        <translation type="vanished">Κέντρο Ελέγχου</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>All Windows</source>
        <translation>Όλα τα Παράθυρα</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Launcher</source>
        <translation>Εκκινητής Εφαρμογών</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Desktop</source>
        <translation>Επιφάνεια Εργασίας</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>None</source>
        <translation>Κανένα</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="58"/>
        <source>Close Window</source>
        <translation>Κλείσιμο Παραθύρου</translation>
    </message>
</context>
</TS>