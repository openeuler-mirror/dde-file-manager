#include "abstractscreen.h"

AbstractScreen::AbstractScreen(QObject *parent) : QObject(parent)
{

}

AbstractScreen::~AbstractScreen()
{

}
