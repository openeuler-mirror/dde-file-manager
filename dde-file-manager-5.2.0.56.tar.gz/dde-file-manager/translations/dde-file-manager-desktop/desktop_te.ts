<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="te">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <source>Browse the file system</source>
            <translation>దస్త్ర వ్యవస్థను విహరించు</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Deepin File Manager</source>
            <translation>దస్త్ర నిర్వాహకం</translation>
        </message>
        <message>
            <location filename="Desktop Action new-window]Name" line="0"/>
            <source>New Window</source>
            <translation type="unfinished"/>
        </message>
    </context>
</TS>
