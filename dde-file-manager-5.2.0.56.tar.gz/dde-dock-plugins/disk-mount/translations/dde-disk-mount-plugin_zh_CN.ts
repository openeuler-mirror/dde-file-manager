<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>DeepinStorage</name>
    <message>
        <source>%1 Volume</source>
        <translation>%1 卷</translation>
    </message>
</context>
<context>
    <name>DiskControlItem</name>
    <message>
        <source>Unknown</source>
        <translation>容量未知</translation>
    </message>
</context>
<context>
    <name>DiskControlWidget</name>
    <message>
        <source>Disk is busy, cannot eject now</source>
        <translation>磁盘文件被占用，无法弹出</translation>
    </message>
    <message>
        <source>dde-file-manager</source>
        <translation>dde-file-manager</translation>
    </message>
</context>
<context>
    <name>DiskMountPlugin</name>
    <message>
        <source>Disk</source>
        <translation>磁盘</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <source>Unmount all</source>
        <translation>卸载全部</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Device has been removed</source>
        <translation>设备已被移除</translation>
    </message>
</context>
</TS>
