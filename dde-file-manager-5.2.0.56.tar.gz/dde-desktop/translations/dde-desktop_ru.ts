<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.1">
<context>
    <name>CanvasGridView</name>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2482"/>
        <source>Icon size</source>
        <translation>Размер значка</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2488"/>
        <source>Auto merge</source>
        <translation>Автоматическое объединение</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2503"/>
        <source>Auto arrange</source>
        <translation>Автоматическое размещение</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2559"/>
        <source>Set Wallpaper</source>
        <translation>Установить в Качестве Обоев</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2561"/>
        <source>Wallpaper and Screensaver</source>
        <translation>Обои и Заставка рабочего стола</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2642"/>
        <source>Properties</source>
        <translation>Свойства</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2543"/>
        <source>Display Settings</source>
        <translation>Настройки Экрана</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2552"/>
        <source>Corner Settings</source>
        <translation>Угловая Навигация</translation>
    </message>
</context>
<context>
    <name>DesktopItemDelegate</name>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="40"/>
        <source>Tiny</source>
        <translation>Крошечный</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="41"/>
        <source>Small</source>
        <translation>Маленький</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="42"/>
        <source>Medium</source>
        <translation>Средний</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="43"/>
        <source>Large</source>
        <translation>Большой</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="44"/>
        <source>Super large</source>
        <translation>Очень большой</translation>
    </message>
</context>
<context>
    <name>DesktopMain</name>
    <message>
        <location filename="../main.cpp" line="131"/>
        <source>Desktop</source>
        <translation>Рабочий Стол</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="450"/>
        <source>Wallpaper Slideshow</source>
        <translation>Слайд-шоу Обоев рабочего стола</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="482"/>
        <source>When login</source>
        <translation>При входе</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="484"/>
        <source>When wakeup</source>
        <translation>При пробуждении</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="528"/>
        <source>Require a password on wakeup</source>
        <translation>Требовать пароль при пробуждении</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="558"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="559"/>
        <source>Wait:</source>
        <translation>Задержка:</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="592"/>
        <source>Wallpaper</source>
        <translation>Обои Рабочего стола</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="593"/>
        <source>Screensaver</source>
        <translation>Заставка Рабочего стола</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="666"/>
        <source>Only desktop</source>
        <translation>Только рабочий стол</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="667"/>
        <source>Only lock screen</source>
        <translation>Только экран блокировки</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="695"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
</context>
<context>
    <name>ZoneMainWindow</name>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Fast Screen Off</source>
        <translation>Погасить</translation>
    </message>
    <message>
        <source>Control Center</source>
        <translation type="vanished">Центр Управления</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>All Windows</source>
        <translation>Все Окна</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Launcher</source>
        <translation>Выбор Программ</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Desktop</source>
        <translation>Рабочий Стол</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="58"/>
        <source>Close Window</source>
        <translation>Закрыть Окно</translation>
    </message>
</context>
</TS>