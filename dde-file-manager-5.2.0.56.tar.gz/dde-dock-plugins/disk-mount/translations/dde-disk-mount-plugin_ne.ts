<?xml version="1.0" ?><!DOCTYPE TS><TS language="ne" version="2.1">
<context>
    <name>DeepinStorage</name>
    <message>
        <location filename="../dattachedudisks2device.cpp" line="100"/>
        <location filename="../dattachedudisks2device.cpp" line="115"/>
        <source>%1 Volume</source>
        <translation>% 1 खण्ड</translation>
    </message>
</context>
<context>
    <name>DiskControlWidget</name>
    <message>
        <location filename="../diskcontrolwidget.cpp" line="215"/>
        <location filename="../diskcontrolwidget.cpp" line="223"/>
        <location filename="../diskcontrolwidget.cpp" line="294"/>
        <location filename="../diskcontrolwidget.cpp" line="455"/>
        <source>Disk is busy, cannot eject now</source>
        <translation>डिस्क व्यस्त छ, भर्खरै निकाल्न सक्दैन</translation>
    </message>
    <message>
        <location filename="../diskcontrolwidget.cpp" line="469"/>
        <source>dde-file-manager</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DiskMountPlugin</name>
    <message>
        <location filename="../diskmountplugin.cpp" line="49"/>
        <source>Disk</source>
        <translation>डिस्क</translation>
    </message>
    <message>
        <location filename="../diskmountplugin.cpp" line="104"/>
        <source>Open</source>
        <translation>खोल्नुहोस्</translation>
    </message>
    <message>
        <location filename="../diskmountplugin.cpp" line="111"/>
        <source>Unmount all</source>
        <translation>सबै अनमाउन्ट गर्नुहोस्</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../diskcontrolwidget.cpp" line="390"/>
        <source>Device has been removed</source>
        <translation>उपकरण हटाईएको छ</translation>
    </message>
</context>
</TS>