<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja" version="2.1">
<context>
    <name>CanvasGridView</name>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2482"/>
        <source>Icon size</source>
        <translation>アイコンサイズ</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2488"/>
        <source>Auto merge</source>
        <translation>自動的にまとめる</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2503"/>
        <source>Auto arrange</source>
        <translation>自動整列</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2559"/>
        <source>Set Wallpaper</source>
        <translation>壁紙を設定</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2561"/>
        <source>Wallpaper and Screensaver</source>
        <translation>壁紙とスクリーンセーバー</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2642"/>
        <source>Properties</source>
        <translation>プロパテイ</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2543"/>
        <source>Display Settings</source>
        <translation>ディスプレイの設定</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2552"/>
        <source>Corner Settings</source>
        <translation>コーナーの設定</translation>
    </message>
</context>
<context>
    <name>DesktopItemDelegate</name>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="40"/>
        <source>Tiny</source>
        <translation>最小</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="41"/>
        <source>Small</source>
        <translation>小</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="42"/>
        <source>Medium</source>
        <translation>中</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="43"/>
        <source>Large</source>
        <translation>大</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="44"/>
        <source>Super large</source>
        <translation>最大</translation>
    </message>
</context>
<context>
    <name>DesktopMain</name>
    <message>
        <location filename="../main.cpp" line="131"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="450"/>
        <source>Wallpaper Slideshow</source>
        <translation>壁紙をスライドショーにする</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="482"/>
        <source>When login</source>
        <translation>ログイン時</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="484"/>
        <source>When wakeup</source>
        <translation>スリープ復帰時</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="528"/>
        <source>Require a password on wakeup</source>
        <translation>スリープ復帰時にパスワードを入力</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="558"/>
        <source>Never</source>
        <translation>使用しない</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="559"/>
        <source>Wait:</source>
        <translation>開始まで:</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="592"/>
        <source>Wallpaper</source>
        <translation>壁紙</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="593"/>
        <source>Screensaver</source>
        <translation>スクリーンセーバー</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="666"/>
        <source>Only desktop</source>
        <translation>デスクトップのみ</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="667"/>
        <source>Only lock screen</source>
        <translation>ロック画面のみ</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="695"/>
        <source>Apply</source>
        <translation>適用</translation>
    </message>
</context>
<context>
    <name>ZoneMainWindow</name>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Fast Screen Off</source>
        <translation>すぐに画面を切る</translation>
    </message>
    <message>
        <source>Control Center</source>
        <translation type="vanished">コントロールセンター</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>All Windows</source>
        <translation>すべてのウィンドウ</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Launcher</source>
        <translation>ランチャー</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Desktop</source>
        <translation>デスクトップ</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>None</source>
        <translation>何もしない</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="58"/>
        <source>Close Window</source>
        <translation>ウィンドウを閉じる</translation>
    </message>
</context>
</TS>