<?xml version="1.0" ?><!DOCTYPE TS><TS language="km_KH" version="2.1">
<context>
    <name>DeepinStorage</name>
    <message>
        <source>%1 Volume</source>
        <translation>%1 កម្រិតសំឡេង</translation>
    </message>
</context>
<context>
    <name>DiskControlItem</name>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DiskControlWidget</name>
    <message>
        <source>Disk is busy, cannot eject now</source>
        <translation>ថាសបានជាប់រវល់, មិនអាចដកចេញឥឡូវបានទេ</translation>
    </message>
    <message>
        <source>dde-file-manager</source>
        <translation>dde-កម្មវិធី​គ្រប់​គ្រង​ឯកសារ</translation>
    </message>
</context>
<context>
    <name>DiskMountPlugin</name>
    <message>
        <source>Disk</source>
        <translation>ថាស</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>បើក</translation>
    </message>
    <message>
        <source>Unmount all</source>
        <translation>Unmount ទំាងអស់</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Device has been removed</source>
        <translation>ឧបករណ៍ត្រូវបានដកចេញ</translation>
    </message>
</context>
</TS>