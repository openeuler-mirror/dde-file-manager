<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Application</name>
    <message>
        <location filename="../main.cpp" line="117"/>
        <source>File Manager</source>
        <translation>File Manager</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="121"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</translation>
    </message>
</context>
</TS>
