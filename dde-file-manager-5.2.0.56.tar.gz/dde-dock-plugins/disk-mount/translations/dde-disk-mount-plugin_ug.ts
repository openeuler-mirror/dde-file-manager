<?xml version="1.0" ?><!DOCTYPE TS><TS language="ug" version="2.1">
<context>
    <name>DeepinStorage</name>
    <message>
        <source>%1 Volume</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>DiskControlItem</name>
    <message>
        <source>Unknown</source>
        <translation>نامەلۇم</translation>
    </message>
</context>
<context>
    <name>DiskControlWidget</name>
    <message>
        <source>Disk is busy, cannot eject now</source>
        <translation>دىسكا ئالدىراش ، ھازىر چىقىرىۋېتەلمەيدۇ</translation>
    </message>
    <message>
        <source>dde-file-manager</source>
        <translation>dde ھۆججەت باشقۇرغۇچ</translation>
    </message>
</context>
<context>
    <name>DiskMountPlugin</name>
    <message>
        <source>Disk</source>
        <translation>دىسكا</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>ئېچىش</translation>
    </message>
    <message>
        <source>Unmount all</source>
        <translation>ھەممىنى چىقىرىۋىتىش</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Device has been removed</source>
        <translation>ئۈسكۈنە چىقىرىۋىتىلدى</translation>
    </message>
</context>
</TS>