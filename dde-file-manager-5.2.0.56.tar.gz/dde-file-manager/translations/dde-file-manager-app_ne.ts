<?xml version="1.0" ?><!DOCTYPE TS><TS language="ne" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">डीपिन फाइल प्रबन्धक</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">फाइल प्रबन्धक एक फाईल प्रबन्धन उपकरण हो जुन स्वतन्त्र रूपमा डीपिन टेक्नोलोजीद्वारा विकसित गरिएको हो, खोजी, प्रतिलिपि, रद्दीटोकरी,  कम्प्रेशन / डिकम्प्रेशन, फाइल सम्पत्ती र अन्य फाइल प्रबन्धन कार्यहरू सहितको रूपमा चित्रित छ।</translation>
    </message>
</context>
</TS>