<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
    <name>CanvasGridView</name>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2482"/>
        <source>Icon size</source>
        <translation>Veľkosť ikony</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2488"/>
        <source>Auto merge</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2503"/>
        <source>Auto arrange</source>
        <translation>Automaticky usporiadať</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2559"/>
        <source>Set Wallpaper</source>
        <translation>Nastaviť pozadie</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2561"/>
        <source>Wallpaper and Screensaver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2642"/>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2543"/>
        <source>Display Settings</source>
        <translation>Nastavenie zobrazenia</translation>
    </message>
    <message>
        <location filename="../view/canvasgridview.cpp" line="2552"/>
        <source>Corner Settings</source>
        <translation>Nastavenia rohov</translation>
    </message>
</context>
<context>
    <name>DesktopItemDelegate</name>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="40"/>
        <source>Tiny</source>
        <translation>Maličké</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="41"/>
        <source>Small</source>
        <translation>Malé</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="42"/>
        <source>Medium</source>
        <translation>Stredné</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="43"/>
        <source>Large</source>
        <translation>Veľké</translation>
    </message>
    <message>
        <location filename="../view/desktopitemdelegate.cpp" line="44"/>
        <source>Super large</source>
        <translation>Veľmi veľké</translation>
    </message>
</context>
<context>
    <name>DesktopMain</name>
    <message>
        <location filename="../main.cpp" line="131"/>
        <source>Desktop</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="450"/>
        <source>Wallpaper Slideshow</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="482"/>
        <source>When login</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="484"/>
        <source>When wakeup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="528"/>
        <source>Require a password on wakeup</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="558"/>
        <source>Never</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="559"/>
        <source>Wait:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="592"/>
        <source>Wallpaper</source>
        <translation>Pozadie</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="593"/>
        <source>Screensaver</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="666"/>
        <source>Only desktop</source>
        <translation>Iba pracovná plocha</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="667"/>
        <source>Only lock screen</source>
        <translation>Iba obrazovka zamknutia</translation>
    </message>
    <message>
        <location filename="../../dde-wallpaper-chooser/frame.cpp" line="695"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ZoneMainWindow</name>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Fast Screen Off</source>
        <translation>Rýchle vypnutie obrazovky</translation>
    </message>
    <message>
        <source>Control Center</source>
        <translation type="vanished">Ovládacie centrum</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>All Windows</source>
        <translation>Všetky okná</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Launcher</source>
        <translation>Spúšťač</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>Desktop</source>
        <translation>Plocha</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="55"/>
        <source>None</source>
        <translation>Nič</translation>
    </message>
    <message>
        <location filename="../../dde-zone/mainwindow.cpp" line="58"/>
        <source>Close Window</source>
        <translation>Zatvoriť okno</translation>
    </message>
</context>
</TS>