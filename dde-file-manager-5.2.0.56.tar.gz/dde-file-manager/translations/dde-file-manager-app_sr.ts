<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Дипин Управник Података</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>Управник Података</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>Управник Података је моћан алат за управљање датотекама који је лак за коришћење. Поседује претрагу, копирање, смеће, запакивање, распакивање, својства датотека и многе друге корисне функције.</translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">Управник Података је алат за управљање датотекама развијен од стране Дипин Технологије који омогућава претрагу, копирање, брисање, компресију, декомпресију, промену атрибута датотека и друге управљачке функционалности.</translation>
    </message>
</context>
</TS>