<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Deepin Dosya Yöneticisi</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>Dosya Yöneticisi</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>Dosya Yöneticisi, arama, kopyalama, çöp kutusu, sıkıştırma/açma, dosya özelliği ve diğer kullanışlı işlevler içeren güçlü ve kullanımı kolay bir dosya yönetim aracıdır.</translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">Dosya Yöneticisi, Deepin Teknoloji ekibi tarafından bağımsız olarak geliştirilmiş arama, kopyalama, çöp kutusu, sıkıştırma/ayıklama, dosya özellikleri ve diğer dosya yönetimi özellikleri sunan bir uygulamadır.</translation>
    </message>
</context>
</TS>