<?xml version="1.0" ?><!DOCTYPE TS><TS language="ms" version="2.1">
<context>
    <name>Application</name>
    <message>
        <source>Deepin File Manager</source>
        <translation type="vanished">Pengurus Fail Deepin</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="108"/>
        <source>File Manager</source>
        <translation>Pengurus Fail</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="112"/>
        <source>File Manager is a powerful and easy-to-use file management tool, featured with searching, copying, trash, compression/decompression, file property and other useful functions.</source>
        <translation>Pengurus Fail merupakan alat pengurusan fail yang mudah digunakan dan hebat, difiturkan dengan fungsi menggelintar, menyalin, tong sampah, pemampatan/penyahmampatan, sifat fail dan lain-lain fungsi berguna.</translation>
    </message>
    <message>
        <source>File Manager is a file management tool independently developed by Deepin Technology, featured with searching, copying, trash, compression/decompression, file property and other file management functions.</source>
        <translation type="vanished">Pengurus Fail merupakan alat pengurusan fail bebas yang dibangunkan oleh Deepin Technology, difiturkan dengan fungsi penggelintaran, penyalinan, tong sampah, pemampatan/penyahmampatan, sifat fail dan lain-lain fungsi pengurusan fail.</translation>
    </message>
</context>
</TS>