<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>DeepinStorage</name>
    <message>
        <source>%1 Volume</source>
        <translation>%1 Volume</translation>
    </message>
</context>
<context>
    <name>DiskControlItem</name>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
    </message>
</context>
<context>
    <name>DiskControlWidget</name>
    <message>
        <source>Disk is busy, cannot eject now</source>
        <translation>Disk is busy, cannot eject now</translation>
    </message>
    <message>
        <source>dde-file-manager</source>
        <translation>dde-file-manager</translation>
    </message>
</context>
<context>
    <name>DiskMountPlugin</name>
    <message>
        <source>Disk</source>
        <translation>Disk</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Open</translation>
    </message>
    <message>
        <source>Unmount all</source>
        <translation>Unmount all</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Device has been removed</source>
        <translation>Device has been removed</translation>
    </message>
</context>
</TS>
